﻿using Demo.Model;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Demo
{
    public partial class Form1 : Form
    {

        ArrayList LstEmp = new ArrayList();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LstEmp.Add(new Tbl_Emp { EmpId = 1, Name = "Mohammed", DoB = Convert.ToDateTime("14-Jun-1991"), Salary = 10000 });
            LstEmp.Add(new Tbl_Emp { EmpId = 2, Name = "Yousuf", DoB = Convert.ToDateTime("08-Aug-1992"), Salary = 20000 });
            LstEmp.Add(new Tbl_Emp { EmpId = 3, Name = "Irfan", DoB = Convert.ToDateTime("08-Dec-1993"), Salary = 20000 });
            LstEmp.Add(new Tbl_Emp { EmpId = 4, Name = "Sultan", DoB = Convert.ToDateTime("08-Nov-1994"), Salary = 30000 });
            LstEmp.Add(new Tbl_Emp { EmpId = 5, Name = "Asad", DoB = Convert.ToDateTime("08-Aug-1995"), Salary = 50000 });
            LstEmp.Add(new Tbl_Emp { EmpId = 6, Name = "Amena", DoB = Convert.ToDateTime("08-Aug-1995"), Salary = 50000 });
            BindDataToGrid(LstEmp);
        }

        void BindDataToGrid(ArrayList obj)
        {
            dgvEmp.DataSource = obj;

            if (dgvEmp == null)
                return;

            dgvEmp.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            if (dgvEmp.Columns.Contains("Name"))
                dgvEmp.Columns["Name"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            ArrayList tempObj = new ArrayList();

            if (e.KeyCode == Keys.F2)
            {
                int? NoOfDays;
                using (FrmNoofDays obj = new FrmNoofDays())
                {
                    obj.ShowInTaskbar = false;
                    obj.ShowDialog();
                    NoOfDays = obj.NoOfdays;
                }
                if (NoOfDays != null)
                {
                    foreach (Tbl_Emp item in LstEmp)
                    {
                        DateTime today = DateTime.Today;
                        DateTime next = new DateTime(today.Year, item.DoB.Month, item.DoB.Day);

                        if (next < today)
                            next = next.AddYears(1);

                        if ((next - today).Days <= NoOfDays)
                            tempObj.Add(item);
                    }
                    BindDataToGrid(tempObj);
                }
            }
            else if (e.KeyCode == Keys.F3)
            {
                int? SalaryRank;
                double tempSalary = 0;
                using (frmHighestSalry obj = new frmHighestSalry())
                {
                    obj.ShowInTaskbar = false;
                    obj.ShowDialog();
                    SalaryRank = obj.SalaryRank;
                }
                if (SalaryRank != null)
                {
                    List<double> sal = new List<double>();
                    foreach (Tbl_Emp item in LstEmp)
                    {
                        if (!sal.Contains(item.Salary))
                            sal.Add(item.Salary);
                    }
                    sal.OrderByDescending(x => x);
                    if (SalaryRank > 0 && SalaryRank <= sal.Count)
                    {
                        tempSalary = sal[(int)SalaryRank - 1];
                        foreach (Tbl_Emp item in LstEmp)
                        {
                            if (tempSalary == item.Salary)
                                tempObj.Add(item);
                        }
                    }
                    BindDataToGrid(tempObj);
                }
            }
            else if (e.KeyCode == Keys.F5)
                BindDataToGrid(LstEmp);
        }
    }
}

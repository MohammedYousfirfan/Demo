﻿using System;

namespace Demo.Model
{
    public class Tbl_Emp
    {
        public int EmpId { get; set; }
        public string Name { get; set; }
        public DateTime DoB { get; set; }
        public double Salary { get; set; }
    }
}

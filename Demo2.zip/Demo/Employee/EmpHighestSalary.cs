﻿using Employee.Model;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee
{
    public class EmpHighestSalary : Employee, IEmployee2
    {
        public ArrayList LstHighestSalary(int SalaryRank)
        {
            ArrayList LstEmp = new ArrayList();
            List<double> sal = new List<double>();
            double tempSalary = 0;
            foreach (Tbl_Emp item in LoadEmp())
            {
                if (!sal.Contains(item.Salary))
                    sal.Add(item.Salary);
            }
            sal.OrderByDescending(x => x);
            if (SalaryRank > 0 && SalaryRank <= sal.Count)
            {
                tempSalary = sal[(int)SalaryRank - 1];
                foreach (Tbl_Emp item in Employee.LoadEmp())
                {
                    if (tempSalary == item.Salary)
                        LstEmp.Add(item);
                }
            }
            return LstEmp;
        }
    }
}

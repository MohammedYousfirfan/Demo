﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee.Model
{
    public class Tbl_Emp
    {
        public int EmpId { get; set; }
        public string Name { get; set; }
        public DateTime DoB { get; set; }
        public double Salary { get; set; }
    }
}

﻿using Employee.Model;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee
{
    public class EmpUpCommingBirthday : Employee, IEmployee1
    {
        public ArrayList LstUpcommingBirthdayEmp(int NoOfDays)
        {
            ArrayList LstEmp = new ArrayList();
            foreach (Tbl_Emp item in LoadEmp())
            {
                DateTime today = DateTime.Today;
                DateTime next = new DateTime(today.Year, item.DoB.Month, item.DoB.Day);

                if (next < today)
                    next = next.AddYears(1);

                if ((next - today).Days <= NoOfDays)
                    LstEmp.Add(item);
            }
            return LstEmp;
        }
    }
}

﻿using Employee.Model;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee
{
    public class Employee  
    {
        public static ArrayList LoadEmp()
        {
            ArrayList LstEmp = new ArrayList();
            LstEmp.Add(new Tbl_Emp { EmpId = 1, Name = "Mohammed", DoB = Convert.ToDateTime("14-Jun-1991"), Salary = 10000 });
            LstEmp.Add(new Tbl_Emp { EmpId = 2, Name = "Yousuf", DoB = Convert.ToDateTime("08-Aug-1992"), Salary = 20000 });
            LstEmp.Add(new Tbl_Emp { EmpId = 3, Name = "Irfan", DoB = Convert.ToDateTime("08-Dec-1993"), Salary = 20000 });
            LstEmp.Add(new Tbl_Emp { EmpId = 4, Name = "Sultan", DoB = Convert.ToDateTime("08-Nov-1994"), Salary = 30000 });
            LstEmp.Add(new Tbl_Emp { EmpId = 5, Name = "Asad", DoB = Convert.ToDateTime("08-Aug-1995"), Salary = 50000 });
            LstEmp.Add(new Tbl_Emp { EmpId = 6, Name = "Amena", DoB = Convert.ToDateTime("08-Aug-1995"), Salary = 50000 });
            return LstEmp;
        }

       
    }
}

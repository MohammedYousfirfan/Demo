﻿using Employee;
using System;
using System.Collections;
using System.Windows.Forms;

namespace Demo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            BindDataToGrid(Employee.Employee.LoadEmp());
        }

        void BindDataToGrid(ArrayList obj)
        {
            dgvEmp.DataSource = obj;

            if (dgvEmp == null)
                return;

            dgvEmp.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            if (dgvEmp.Columns.Contains("Name"))
                dgvEmp.Columns["Name"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F2)
            {
                int? NoOfDays;
                using (FrmNoofDays obj = new FrmNoofDays())
                {
                    obj.ShowInTaskbar = false;
                    obj.ShowDialog();
                    NoOfDays = obj.NoOfdays;
                }
                if (NoOfDays != null)
                {
                    IEmployee1 empObj = new EmpUpCommingBirthday();
                    BindDataToGrid(empObj.LstUpcommingBirthdayEmp((int)NoOfDays));
                }
            }
            else if (e.KeyCode == Keys.F3)
            {
                int? SalaryRank;
                using (frmHighestSalry obj = new frmHighestSalry())
                {
                    obj.ShowInTaskbar = false;
                    obj.ShowDialog();
                    SalaryRank = obj.SalaryRank;
                }
                if (SalaryRank != null)
                {
                    IEmployee2 empObj = new EmpHighestSalary();
                    BindDataToGrid(empObj.LstHighestSalary((int)SalaryRank));
                }
            }
            else if (e.KeyCode == Keys.F5)
                BindDataToGrid(Employee.Employee.LoadEmp());
        }
    }
}
